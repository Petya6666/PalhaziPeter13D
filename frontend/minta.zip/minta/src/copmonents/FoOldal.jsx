function FoOldal() {
    return (
      <div>
        <h1>Üdvözöllek a React Mintában!</h1>
        <p>Ez egy egyszerű mintaalkalmazás, amely bemutatja a React, a React Router és a React Bootstrap alapvető használatát.</p>
        <p>Navigálj a 'Regisztráció' oldalra, hogy kipróbáld a továbbfejlesztett űrlapot validációval és aszinkron adatküldés szimulációval.</p>
      </div>
    );
  }
  export default FoOldal;