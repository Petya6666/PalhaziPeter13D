import React from 'react';

function Loading() {
  return <p>Adatok betöltése...</p>;
}

export default Loading;
