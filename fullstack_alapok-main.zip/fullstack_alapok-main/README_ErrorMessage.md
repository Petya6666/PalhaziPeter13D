# ErrorMessage.jsx

Ez a komponens hibaüzenetet jelenít meg, ha az alkalmazásban hiba történik.

## Props:
- `error`: hibaüzenet szövege
