# Loading.jsx

Ez a komponens a betöltési állapotot jeleníti meg, amikor az adatok még nem érkeztek meg.
