# App.jsx

Ez a fő komponens, amely összeállítja az alkalmazást. Kezeli az állapotokat, API-hívásokat és rendereli a többi komponenst.

## Főbb funkciók:
- Felhasználók lekérése, hozzáadása, szerkesztése, törlése
- Állapotkezelés: `users`, `loading`, `error`, stb.
- Feltételes renderelés hiba vagy betöltés esetén
