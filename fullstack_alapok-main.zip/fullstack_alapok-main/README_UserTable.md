# UserTable.jsx

Ez a komponens a felhasználók listáját jeleníti meg táblázatos formában.

## Props:
- `users`: felhasználók tömbje
- `editingId`: szerkesztés alatt álló ID
- `editedName`, `editedEmail`: szerkesztett értékek
- `handleEditStart`, `handleDelete`, `handleUpdate`, `handleEditCancel`: műveleti függvények
- `setEditedName`, `setEditedEmail`: szerkesztett értékek frissítése
