# UserForm.jsx

Ez a komponens az új felhasználó hozzáadásáért felelős űrlapot jeleníti meg.

## Props:
- `name`, `email`: aktuális értékek
- `setName`, `setEmail`: állapotfrissítők
- `handleSubmit`: űrlap beküldése
